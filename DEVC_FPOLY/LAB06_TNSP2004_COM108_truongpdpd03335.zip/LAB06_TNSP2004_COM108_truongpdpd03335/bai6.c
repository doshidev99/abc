#include <stdio.h>
int main(int argc, char *argr[])
{
	char SV[25];
	char DC[150];
	float diem;
	printf("nhap ho ten SV:");
	gets(SV);
	printf("nhap dia chi:");
	gets(DC);
	printf("nhap diem:");
	scanf("%f", &diem);
	printf("\nhoten: %d\ndiachi %s\ndiem %f,SV,DC,diem");
	return 0;
}