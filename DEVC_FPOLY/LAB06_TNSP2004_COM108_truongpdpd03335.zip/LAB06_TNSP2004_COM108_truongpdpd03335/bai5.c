#include <stdio.h>
int main()
{
    int a;
    int n;
    printf("\nNhap so luong phan tu n = ");
    do
    {
        scanf("%d", &n);
        if (n <= 0)
        {
            printf("\nNhap lai n = ");
        }
    } while (n <= 0);

    for (int i = 0; i < n; i++)
    {
        printf("\nNhap a[%d] = ", i);
        scanf("%d", &a[i]);
    }
    int tg;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (a[i] < a[j])
            {
                tg = a[i];
                a[i] = a[j];
                a[j] = tg;
            }
        }
    }
    printf("\nMang da sap xep la: ");
    for (int i = 0; i < n; i++)
    {
        printf("%5d", a[i]);
    }
    return 0;
}